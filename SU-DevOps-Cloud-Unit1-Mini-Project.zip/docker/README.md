# Docker
docker build -t su-resource-booking:latest .
docker run -p 8080:80 su-resource-booking:latest
Open http://localhost:8080
