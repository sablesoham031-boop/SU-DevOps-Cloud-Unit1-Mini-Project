# Unit 1 Mini Project — Project Document

## 1. Business Problem
Manual college resource booking can cause duplicate reservations, delays and uncertainty about availability.

## 2. Design Thinking
Empathize: understand students, staff and admin.
Define: make resource availability and booking simple.
Ideate: resource list, status, booking, cancellation and dashboard.
Prototype: login, resource, booking and admin screens.
Test: validate common booking tasks and collect feedback.

## 3. Personas
Student — quick booking.
Lab Staff — accurate booking management.
Admin — centralized usage information.

## 4. Functional Requirements
FR-01 Login/RBAC; FR-02 resource listing; FR-03 booking; FR-04 cancellation; FR-05 staff/admin management; FR-06 dashboard.

## 5. Non-Functional Requirements
Security, performance, reliability, maintainability and automated CI/CD.

## 6. MVP
Login, availability, booking, cancellation, management and dashboard.

## 7. DevOps Lifecycle
Plan → Code → Build → Test → Package → Deploy → Monitor → Improve.

## 8. Architecture
User → Web App → Data Layer → CI/CD → Docker → Deployment → Health Check.

## 9. Future Scope
Email notifications, QR resource identification, calendar integration, cloud database, Kubernetes and advanced monitoring.
