# SU - DevOps & Cloud — Unit 1 Mini Project
## Student Resource & Lab Booking System

**Student:** Soham Ravindra Sable  
**GitHub:** soham-031  
**Institute:** Sanjivani University / Sanjivani College of Engineering  
**Class:** AIDS (DSY)

### Objective
A simple college resource booking platform demonstrating Product Engineering, IBM Design Thinking and a practical DevOps lifecycle.

### Features
- Resource availability
- Booking and cancellation
- Staff/Admin management
- Basic dashboard
- Git/GitHub workflow
- Automated CI testing
- Docker packaging
- Deployment-ready structure

### DevOps Flow
GitHub → CI → Test → Docker Build → Deployment → Health Check
