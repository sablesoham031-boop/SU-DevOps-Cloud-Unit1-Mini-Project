from pathlib import Path
def test_required_files():
    root=Path(__file__).resolve().parents[1]
    for f in ["README.md","frontend/index.html","frontend/style.css","frontend/script.js","Dockerfile","Jenkinsfile"]:
        assert (root/f).exists()
def test_title():
    root=Path(__file__).resolve().parents[1]
    assert "Student Resource & Lab Booking System" in (root/"frontend/index.html").read_text()
